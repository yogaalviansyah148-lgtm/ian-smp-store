/* ═══════════════════════════════════════════════════════════
   ZeroNest League — Complete JavaScript
═══════════════════════════════════════════════════════════ */

/* ── Loading Screen ──────────────────────────────────────── */
window.addEventListener('load', () => {
  setTimeout(() => {
    const loader = document.getElementById('loader');
    if (loader) loader.classList.add('hidden');
  }, 2500);
});

/* ── Particle Background ─────────────────────────────────── */
(function initParticles() {
  const canvas = document.getElementById('particles');
  const ctx = canvas.getContext('2d');

  let W, H, particles = [];

  function resize() {
    W = canvas.width = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }
  window.addEventListener('resize', resize);
  resize();

  class Particle {
    constructor() { this.reset(); }
    reset() {
      this.x = Math.random() * W;
      this.y = Math.random() * H;
      this.r = Math.random() * 1.5 + .4;
      this.vx = (Math.random() - .5) * .4;
      this.vy = -Math.random() * .5 - .2;
      this.alpha = Math.random() * .4 + .1;
      this.gold = Math.random() > .6;
    }
    update() {
      this.x += this.vx;
      this.y += this.vy;
      this.alpha -= .0005;
      if (this.y < -10 || this.alpha <= 0) this.reset();
    }
    draw() {
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
      ctx.fillStyle = this.gold
        ? `rgba(255,215,0,${this.alpha})`
        : `rgba(255,255,255,${this.alpha})`;
      ctx.fill();
    }
  }

  for (let i = 0; i < 120; i++) particles.push(new Particle());

  function animate() {
    ctx.clearRect(0, 0, W, H);
    particles.forEach(p => { p.update(); p.draw(); });
    requestAnimationFrame(animate);
  }
  animate();
})();

/* ── Navbar scroll ───────────────────────────────────────── */
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  navbar.classList.toggle('scrolled', window.scrollY > 60);
}, { passive: true });

/* ── Hamburger / Mobile menu ─────────────────────────────── */
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobileMenu');

hamburger?.addEventListener('click', () => {
  const open = mobileMenu.classList.toggle('open');
  hamburger.classList.toggle('open', open);
  hamburger.querySelectorAll('span').forEach((s, i) => {
    s.style.transform = open
      ? i === 0 ? 'translateY(7px) rotate(45deg)' : i === 2 ? 'translateY(-7px) rotate(-45deg)' : 'scaleX(0)'
      : '';
    s.style.opacity = open && i === 1 ? '0' : '';
  });
});

function closeMobile() {
  mobileMenu.classList.remove('open');
  hamburger.classList.remove('open');
  hamburger.querySelectorAll('span').forEach(s => { s.style.transform = ''; s.style.opacity = ''; });
}

/* ── Close mobile menu on outside click ─────────────────── */
document.addEventListener('click', (e) => {
  if (!hamburger?.contains(e.target) && !mobileMenu?.contains(e.target)) {
    closeMobile();
  }
});

/* ── Smooth Reveal on Scroll ─────────────────────────────── */
const revealObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    });
  },
  { threshold: 0.12 }
);

document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

/* ── Counter Animation ───────────────────────────────────── */
function animateCounter(el) {
  const target = parseInt(el.dataset.target);
  const duration = 1800;
  const step = target / (duration / 16);
  let current = 0;

  const timer = setInterval(() => {
    current += step;
    if (current >= target) {
      current = target;
      clearInterval(timer);
    }
    el.textContent = Math.floor(current).toLocaleString('id-ID');
  }, 16);
}

const counterObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting && !entry.target.dataset.counted) {
        entry.target.dataset.counted = 'true';
        animateCounter(entry.target);
      }
    });
  },
  { threshold: 0.5 }
);

document.querySelectorAll('.counter').forEach(el => counterObserver.observe(el));

/* ── Copy IP ─────────────────────────────────────────────── */
function copyIP() {
  const ip = 'play.zeronest.net';
  if (navigator.clipboard) {
    navigator.clipboard.writeText(ip).then(() => showToast('✅ IP Server disalin: ' + ip));
  } else {
    const el = document.createElement('input');
    el.value = ip;
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
    showToast('✅ IP Server disalin: ' + ip);
  }
}

document.getElementById('copyIpNav')?.addEventListener('click', copyIP);

/* ── Toast Notification ──────────────────────────────────── */
let toastTimer;
function showToast(msg) {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 3000);
}

/* ── Buy Modal ───────────────────────────────────────────── */
function showBuyModal(rankName, price) {
  document.getElementById('modalTitle').textContent = 'Beli Paket ' + rankName;
  document.getElementById('modalPrice').textContent = 'Rp ' + price;
  document.getElementById('buyModal').classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeBuyModal(event) {
  if (event.target === document.getElementById('buyModal')) {
    document.getElementById('buyModal').classList.remove('active');
    document.body.style.overflow = '';
  }
}

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.getElementById('buyModal').classList.remove('active');
    document.body.style.overflow = '';
  }
});

/* ── Smooth Scroll for anchor links ─────────────────────── */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      e.preventDefault();
      const navH = document.getElementById('navbar').offsetHeight;
      const top = target.getBoundingClientRect().top + window.scrollY - navH - 16;
      window.scrollTo({ top, behavior: 'smooth' });
    }
  });
});

/* ── Active nav link highlight ───────────────────────────── */
const sections = document.querySelectorAll('section[id]');
const navLinks = document.querySelectorAll('.nav-links a');

window.addEventListener('scroll', () => {
  let current = '';
  const navH = navbar.offsetHeight;
  sections.forEach(section => {
    const top = section.getBoundingClientRect().top;
    if (top <= navH + 80) current = section.getAttribute('id');
  });
  navLinks.forEach(link => {
    link.style.color = '';
    if (link.getAttribute('href') === '#' + current) {
      link.style.color = 'var(--gold)';
    }
  });
}, { passive: true });

/* ── Neon cursor trail (desktop only) ────────────────────── */
if (window.matchMedia('(hover: hover) and (pointer: fine)').matches) {
  const trail = [];
  const TRAIL_LEN = 8;

  for (let i = 0; i < TRAIL_LEN; i++) {
    const dot = document.createElement('div');
    dot.style.cssText = `
      position: fixed; width: ${6 - i * .5}px; height: ${6 - i * .5}px;
      border-radius: 50%; pointer-events: none; z-index: 99998;
      background: rgba(255,215,0,${.5 - i * .06});
      transition: transform .1s;
      mix-blend-mode: screen;
    `;
    document.body.appendChild(dot);
    trail.push({ el: dot, x: 0, y: 0 });
  }

  let mouseX = 0, mouseY = 0;
  window.addEventListener('mousemove', e => { mouseX = e.clientX; mouseY = e.clientY; });

  function animateTrail() {
    let lx = mouseX, ly = mouseY;
    trail.forEach((dot, i) => {
      const ease = i === 0 ? 1 : .35;
      dot.x += (lx - dot.x) * ease;
      dot.y += (ly - dot.y) * ease;
      dot.el.style.left = (dot.x - dot.el.offsetWidth / 2) + 'px';
      dot.el.style.top = (dot.y - dot.el.offsetHeight / 2) + 'px';
      lx = dot.x; ly = dot.y;
    });
    requestAnimationFrame(animateTrail);
  }
  animateTrail();
}

/* ── Card tilt effect ────────────────────────────────────── */
if (window.matchMedia('(hover: hover)').matches) {
  document.querySelectorAll('.vip-card, .feat-card').forEach(card => {
    card.addEventListener('mousemove', e => {
      const rect = card.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width - .5;
      const y = (e.clientY - rect.top) / rect.height - .5;
      card.style.transform = `perspective(600px) rotateY(${x * 6}deg) rotateX(${-y * 6}deg) translateY(-6px)`;
    });
    card.addEventListener('mouseleave', () => {
      card.style.transform = '';
    });
  });
}

/* ── Loader tip cycling ──────────────────────────────────── */
const tips = [
  'Initializing server connection…',
  'Loading player data…',
  'Joining ZeroNest League…',
  'Preparing epic experience…',
];
let tipIdx = 0;
const tipEl = document.querySelector('.loader-tip');
if (tipEl) {
  const tipInterval = setInterval(() => {
    tipIdx = (tipIdx + 1) % tips.length;
    tipEl.style.opacity = 0;
    setTimeout(() => {
      tipEl.textContent = tips[tipIdx];
      tipEl.style.opacity = 1;
    }, 300);
  }, 600);
  setTimeout(() => clearInterval(tipInterval), 2500);
}
